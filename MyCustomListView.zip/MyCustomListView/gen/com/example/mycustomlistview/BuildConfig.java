/** Automatically generated file. DO NOT MODIFY */
package com.example.mycustomlistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}