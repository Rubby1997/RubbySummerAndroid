package com.example.mycustomlistview;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.example.search.MyAdapter;
import com.example.search.R;
import com.example.search.Student;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener    {
	MyAdapter adapter;
	
	
	ArrayList<Student> source;
	ArrayList<Student> list;
	ListView lv;
	EditText txtSearch;
	int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        list = new ArrayList<Student>();
        source = new ArrayList<Student>();
        
        this.txtSearch = (EditText) this.findViewById(R.id.editText1);
        this.lv = (ListView) this.findViewById(R.id.listView1);
        
        adapter = new MyAdapter(this,list);
        this.lv.setAdapter(adapter);
     
       this.source.add(new Student(R.drawable.img1,"ALPHA","BSIT"));
       this.source.add(new Student(R.drawable.img2,"Bravo","BSCS"));
       this.source.add(new Student(R.drawable.img3,"Charlie","BSEE"));
       this.source.add(new Student(R.drawable.img4,"Delta","BSECE"));
       this.source.add(new Student(R.drawable.img5,"Echo","BSCREAM"));
       this.source.add(new Student(R.drawable.img6,"Foxtrot","BSHRM"));
       this.source.add(new Student(R.drawable.img7,"Gamble","BSOA"));
       this.source.add(new Student(R.drawable.img8,"LOL","BSEED"));
        
        
        
        this.lv = (ListView) this.findViewById(R.id.listView1);
       adapter1 = new ItemAdapter(this,source);
       this.lv.setAdapter(adapter1);
    
     this.lv.setOnItemClickListener(this);
     
     this.txtSearch.addTextChangedListener(new TextWatcher(){

		@Override
		public void afterTextChanged(Editable arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
				int arg3) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onTextChanged(CharSequence arg0, int arg1, int arg2,
				int arg3) {
			
			list.clear();
			
			Pattern p=Pattern.compile(arg0.toString());
			for(int i=0;i<source.size();i++){
				Matcher m=p.matcher((CharSequence) source.get(i));
			        if(m.find()){
			        	list.add(source.get(i));
			        	adapter1.notifyDataSetChanged();
			        }
			}
			
		}});
     
     
     
    }


    
		
	


	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
		LinearLayout dialoglayout=new LinearLayout(this);
		 dialoglayout.setOrientation(LinearLayout.HORIZONTAL);
		
		 ImageView iv=new ImageView(this);
		 TextView name_course=new TextView(this);
		 
		 iv.setImageResource(list.get(arg2).getImage());
		 String namecourse= list.get(arg2).getName()+""+list.get(arg2).getCourse();
		
		name_course.setText(namecourse);
		
		dialoglayout.addView(iv);
		dialoglayout.addView(name_course);
		
		AlertDialog.Builder builder =new AlertDialog.Builder(this);
		 builder.setTitle("Selected Item");
		 builder.setView(dialoglayout);
		 builder.setNeutralButton("Okey", null);
		 
		 AlertDialog dialog = builder.create();
		 dialog.show();
		
		
		
		
		
	}
     String s=this.lv.getItemAtPosition(arg2).toString();


	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}
     
}

