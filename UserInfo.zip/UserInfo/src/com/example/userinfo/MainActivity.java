package com.example.userinfo;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class MainActivity extends Activity {

    
	EditText txtIdno,txtName;
	Spinner cboCourse;
	RadioGroup myGender;
	Button btnOkey;
	
	
	
	
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
   
    this.txtIdno = (EditText) this.findViewById(R.id.editText1);
    this.txtName = (EditText) this.findViewById(R.id.editText2);
    this.cboCourse = (Spinner) this.findViewById(R.id.spinner1);
    this.myGender = this.findViewById(R.id.ra)
    
   
    
    
    
    
    
    
    }


   
    
}
